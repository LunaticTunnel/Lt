#/bin/bash
BlueCyan='\e[5;36m'
Xark='\e[0m'
ungu='\033[0;35m'
yellow='\e[33m'
WhiteBe='\e[5;37m'
GreenBe='\e[5;32m'
BlueCyan='\e[5;36m'
Xark='\e[0m'
clear

function baris_panjang() {
  echo -e "${BlueCyan} ——————————————————————————— ${Xark} "
}
# . 1
function Create_Account() {
  add-ssr
}
# . 2
function Create_Trial() {
  trial-ssr
}
# . 3
function List_Member() {
  member-ssr
}
# . 4
function Delete_Account() {
  delet-ssr
}
# . 5
function Changes_Limit() {
  change-limit-xray
}
# . 6
function Renew_Account() {
  renew-ssr
}
# . 7
function Check_Account() {
  user-ssr
}

function Monitor_Ssr(){
 cek-ssr
}

function Banner() {
  baris_panjang
  echo -e "${ungu}           SSR      ${Xark} "
  baris_panjang
}

function Menu_Features() {
  baris_panjang
  echo -e "${ungu}"
  echo " 1. Create shadowsock   "
  echo " 2. Trial shadowsock "
  echo " 3. Delete shadowsock    "
  echo " 4. List Member "
  echo " 5. Renew Account "
  echo " 6. Change Limit IP "
  echo " 7. Check Details Sadowsock "
  echo " 8. Check Monitor Ssr "
  echo -e "${Xark}"
  echo -e "${yellow} x. Exit ${Xark}"
  baris_panjang
}

Banner
Menu_Features
read -p "Select [1/7 or x] :  " Ltt
case $Ltt in
1) clear ; Create_Account ;;
2) clear ; Create_Trial ;;
3) clear ; Delete_Account ;;
4) clear ; List_Member ;;
5) clear ; Renew_Account ;;
6) clear ; Changes_Limit ;;
7) clear ; Check_Account ;;
8) clear ; Monitor_Ssr ;;
*) exit ;;
esac
